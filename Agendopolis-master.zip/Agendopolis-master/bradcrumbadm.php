<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="homeadm.php">Inicio</a></li>
    <li class="breadcrumb-item active"><a href="">Atualização</a></li>
  </ol>
</nav>
