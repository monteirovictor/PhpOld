<?php
require_once("dao/factoryconexao.php");

$id = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);
$result_usuario = "SELECT * FROM agendopolis WHERE agen_sq_agendopolis = '$id'";
$resultado_usuario = mysqli_query($conn, $result_usuario);
$row_usuario = mysqli_fetch_assoc($resultado_usuario);

?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="utf-8">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <script src="https://code.jquery.com/jquery-3.3.1.js"></script>

  <title></title>
  <?php require_once("navbaradm.php"); ?>
</head>
<body><br>
      <div class="container">
        <h1>Atualização de Usuários</h1><br>
        <form class="" action="agendar.php" method="post">
          <h2>Agendamento</h2>
          <?php require_once("breadcrumb.php");?><br>

          <div class="form row">
            <div class="col-md 6">
              <label for="">Solicitante</label>
              <input type="text" name="agen_tx_solicitante" value="<?php echo $row_usuario['agen_sq_agendopolis'];?>" class="form-control" readonly>
            </div>
            <div class="form-group col-md-6">
              <label for="">Data do Pedido</label>
              <input type="text" name="agen_tx_datadia" value="<?php echo $row_usuario['agen_tx_datadia'];?>" class="form-control" readonly>
            </div>
            <div class="form-group form-group col-md-6">
              <label for="exampleFormControlSelect1">Recurso</label>
              <select class="form-control" id="agen_sq_recurso" name="agen_sq_recurso">
                <?php
                $recurso="";
                $sql="SELECT DISTINCT rec_sq_recurso,rec_tx_recurso
                FROM recurso";
                $query=mysqli_query($conn,$sql);
                while ($row = mysqli_fetch_assoc($query)) {
                  $selected = "";
                  if($rec_sq_recurso==$row["rec_sq_recurso"]){
                    $selected = "selected";
                  }

                  $recurso.="<option value=" . $row['rec_sq_recurso'] . " $selected>" . $row['rec_tx_recurso'] . "</option>";
                }

                echo $recurso;
                ?>
              </select>
            </div>
            <div class="form-group form-group col-md-6">
              <label for="">Tema Reunião</label>
              <input type="text" name="agen_tx_temareuniao" value="<?php echo $row_usuario['agen_tx_temareuniao']; ?>" class="form-control">
            </div>
          </div>
          <div class="form row">
            <div class="form-group form-group col-md-6">
              <label for="">Inicio Reunião</label>
              <input type="text" name="agen_tx_inicio" value="<?php echo $row_usuario['agen_tx_inicio']; ?>" class="form-control">
            </div>
            <div class="form-group form-group col-md-6">
              <label for="">Término Reunião</label>
              <input type="text" name="agen_tx_fim" value="<?php echo $row_usuario['agen_tx_fim'];?>" class="form-control">
            </div>
            <div class="container">
              <div class="form-group">
                <div class="text-right">
                  <button type="submit" class="btn btn-primary mb-2" name="salvar">Enviar</button>
                </div>
              </div>
            </div>
          </form>
      </div>
      </body>
      <script src="https://cdnjs.cloudflare.com/ajax/controller/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
      </html>
