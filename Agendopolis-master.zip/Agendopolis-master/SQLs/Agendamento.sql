-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Tempo de geração: 06/08/2019 às 01:00
-- Versão do servidor: 10.3.16-MariaDB
-- Versão do PHP: 7.1.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `Agendamento`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `agendopolis`
--

CREATE TABLE `agendopolis` (
  `agen_sq_agendopolis` int(11) NOT NULL,
  `agen_tx_solicitante` varchar(50) DEFAULT NULL,
  `agen_tx_datadia` varchar(40) DEFAULT NULL,
  `agen_tx_temareuniao` varchar(50) DEFAULT NULL,
  `agen_tx_inicio` varchar(50) DEFAULT NULL,
  `agen_tx_fim` varchar(50) DEFAULT NULL,
  `agen_sq_user` int(11) DEFAULT NULL,
  `agen_sq_recurso` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Despejando dados para a tabela `agendopolis`
--

INSERT INTO `agendopolis` (`agen_sq_agendopolis`, `agen_tx_solicitante`, `agen_tx_datadia`, `agen_tx_temareuniao`, `agen_tx_inicio`, `agen_tx_fim`, `agen_sq_user`, `agen_sq_recurso`) VALUES
(1, 'victor maia', '06/08/19', 'a', 'a', 'a', 1, 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `recurso`
--

CREATE TABLE `recurso` (
  `rec_sq_recurso` int(11) NOT NULL,
  `rec_tx_recurso` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Despejando dados para a tabela `recurso`
--

INSERT INTO `recurso` (`rec_sq_recurso`, `rec_tx_recurso`) VALUES
(1, 'Lenovo'),
(2, 'Samsung'),
(3, 'Positivo'),
(4, 'HP');

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `usua_sq_usuarios` int(11) NOT NULL,
  `usua_tx_nomes` varchar(50) DEFAULT NULL,
  `usua_tx_login` varchar(50) DEFAULT NULL,
  `usua_tx_senha` varchar(50) DEFAULT NULL,
  `niveis_acesso_id` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Despejando dados para a tabela `usuarios`
--

INSERT INTO `usuarios` (`usua_sq_usuarios`, `usua_tx_nomes`, `usua_tx_login`, `usua_tx_senha`, `niveis_acesso_id`) VALUES
(1, 'victor maia', 'victor.maia', '202cb962ac59075b964b07152d234b70', '1');

--
-- Índices de tabelas apagadas
--

--
-- Índices de tabela `agendopolis`
--
ALTER TABLE `agendopolis`
  ADD PRIMARY KEY (`agen_sq_agendopolis`),
  ADD KEY `agen_sq_recurso` (`agen_sq_recurso`),
  ADD KEY `agen_sq_user` (`agen_sq_user`);

--
-- Índices de tabela `recurso`
--
ALTER TABLE `recurso`
  ADD PRIMARY KEY (`rec_sq_recurso`);

--
-- Índices de tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`usua_sq_usuarios`);

--
-- AUTO_INCREMENT de tabelas apagadas
--

--
-- AUTO_INCREMENT de tabela `agendopolis`
--
ALTER TABLE `agendopolis`
  MODIFY `agen_sq_agendopolis` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `recurso`
--
ALTER TABLE `recurso`
  MODIFY `rec_sq_recurso` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `usua_sq_usuarios` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Restrições para dumps de tabelas
--

--
-- Restrições para tabelas `agendopolis`
--
ALTER TABLE `agendopolis`
  ADD CONSTRAINT `agen_sq_recurso` FOREIGN KEY (`agen_sq_recurso`) REFERENCES `recurso` (`rec_sq_recurso`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `agen_sq_user` FOREIGN KEY (`agen_sq_user`) REFERENCES `usuarios` (`usua_sq_usuarios`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
