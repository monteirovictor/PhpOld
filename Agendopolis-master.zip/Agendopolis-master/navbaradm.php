<!--Navbar com os menus do sistemas -->
<?php
   //Arquivo de conexao;
   include_once("dao/factoryconexao.php");
   ?>
   <?php
     session_start();
     echo "User: ". $_SESSION['usuarioNome'];
   ?>
<nav class="navbar navbar-expand-lg" style="background-color:#1D398D">
  <a class="navbar-brand" href="#">Navbar</a>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="homeadm.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="">Atualizar</a>
      </li>
    </ul>
  </div>
  <form class="form-inline my-2 my-lg-0">
    <a class="nav-link" href="controller/sessionlogout.php">Logout</a>

  </form>
</nav>
