<?php
require_once("dao/factoryconexao.php");

$sql = "SELECT agen_sq_agendopolis,agen_tx_solicitante,agen_tx_datadia,agen_tx_temareuniao,
agen_tx_inicio,agen_tx_fim from agendopolis";
$result = $conn->query($sql);
$arr_users = [];
if ($result->num_rows > 0) {
    $arr_users = $result->fetch_all(MYSQLI_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="utf-8">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <link rel="stylesheet" href="//cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
  <script src="https://code.jquery.com/jquery-3.3.1.js"></script>

  <title></title>
  <?php require_once("navbaradm.php"); ?>
</head>
<body><br>
      <div class="container">
        <h1>Reuniões Agendadas</h1><br>

        <table id="usetTable" class="table">
              <thead>
                  <th>Solicitante</th>
                  <th>Dia</th>
                  <th>Tema Reunião</th>
                  <th>Inicio</th>
                  <th>Fim</th>
                  <th>Atualizar</th>
              </thead>
              <tbody>
                  <?php if(!empty($arr_users)) { ?>
                      <?php foreach($arr_users as $user) { ?>
                          <tr>
                              <td><?php echo $user['agen_tx_solicitante']; ?></td>
                              <td><?php echo $user['agen_tx_datadia']; ?></td>
                                <td><?php echo $user['agen_tx_temareuniao']; ?></td>
                              <td><?php echo $user['agen_tx_inicio']; ?></td>
                              <td><?php echo $user['agen_tx_fim']; ?></td>
                              <td><?php echo "<a href='atualizaradm.php?id=" . $user['agen_sq_agendopolis'] . "'>Reprovar</a>"; ?></td>
                          </tr>
                      <?php } ?>
                  <?php } ?>
              </tbody>
          </table>
      </div>
         <script type="text/javascript" src="//cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
         <script>
             $(document).ready(function() {
                 $('#usetTable').DataTable();
             } );
         </script>
      </body>
      <script src="https://cdnjs.cloudflare.com/ajax/controller/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
      </html>
