<?php

require_once("dao/factoryconexao.php");


?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="utf-8">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <title></title>
  <?php require_once("navbar.php"); ?>
</head>
<body><br>
  <div class="container">
    <?php
    // Comparação de Salvar
    if(isset($_POST["salvar"])){

      require_once 'controller/formvalidator.php';
      //O método abaixo é para validação de dados.
      $validator= new FormValidator();
      $validator->addValidation("agen_sq_recurso","req","Campo em Branco !");
      $validator->addValidation("agen_tx_temareuniao","req","Campo em Branco !");
      $validator->addValidation("agen_tx_inicio","req","Campo em Branco !");
      $validator->addValidation("agen_tx_fim","req","Campo em Branco !");


      if ($validator->ValidateForm()) {

        // $idusuario = (int)$_SESSION['user']['iduser'];

        $solicitante=$_POST['agen_tx_solicitante'];
        $agen_tx_datadia=$_POST['agen_tx_datadia'];
        $agen_sq_recurso= (int)$_POST['agen_sq_recurso'];
        $agen_tx_temareuniao=$_POST['agen_tx_temareuniao'];
        $agen_tx_inicio=$_POST['agen_tx_inicio'];
        $agen_tx_fim=$_POST['agen_tx_fim'];
        $idusuarioSession = $_SESSION['usuarioId'];

        $sql="INSERT INTO agendopolis (agen_tx_solicitante,agen_tx_datadia,agen_sq_recurso,
          agen_tx_temareuniao,agen_tx_inicio,agen_tx_fim,agen_sq_user)

          VALUES('$solicitante','$agen_tx_datadia','$agen_sq_recurso','$agen_tx_temareuniao',
            '$agen_tx_inicio','$agen_tx_fim','$idusuarioSession')";
            $query=mysqli_query($conn,$sql);


        }else{
            echo "<B>Campos em Branco no Formulário</B>";

            $solicitante=$_POST['agen_tx_solicitante'];
            $agen_tx_datadia=$_POST['agen_tx_datadia'];
            $agen_sq_recurso= $_POST['agen_sq_recurso'];
            $agen_tx_temareuniao=$_POST['agen_tx_temareuniao'];
            $agen_tx_inicio=$_POST['agen_tx_inicio'];
            $agen_tx_fim=$_POST['agen_tx_fim'];

          }
        }
        //NÃO É POST

        else{

          // Regasta as informações do form, para não redigitar

          $agen_sq_recurso = "";
          $agen_tx_temareuniao = "";
          $agen_tx_inicio = "";
          $agen_tx_fim ="";
          $agen_tx_solicitante="";
          $agen_tx_datadia="";


          // pega os usuários/id por meio de session;
          $usuarioSession = $_SESSION['usuarioNome'];
          $idusuarioSession = $_SESSION['usuarioId'];



          $solicitante = "";
          $sql2 = "SELECT usua_tx_nomes FROM usuarios
          WHERE usua_tx_nomes = '$usuarioSession' &&
          usua_sq_usuarios = '$idusuarioSession'";
          $query = mysqli_query($conn,$sql2);
          while ($row = mysqli_fetch_assoc($query)) {
            $solicitante =  $row['usua_tx_nomes'] ;
          }

        }
        ?>
        <form class="" action="agendar.php" method="post">
          <h2>Agendamento</h2>
          <?php require_once("breadcrumb.php");?><br>
          <div class="form row">
            <div class="col-md 6">
              <label for="">Solicitante</label>
              <input type="text" name="agen_tx_solicitante" value="<?php echo $solicitante; ?>" class="form-control" readonly>
            </div>
            <div class="form-group col-md-6">
              <label for="">Data do Pedido</label>
              <input type="text" name="agen_tx_datadia" value="<?php echo date("d/m/y");?>" class="form-control" readonly>
            </div>
            <div class="form-group form-group col-md-6">
              <label for="exampleFormControlSelect1">Recurso</label>
              <select class="form-control" id="agen_sq_recurso" name="agen_sq_recurso">
                <?php
                $recurso="";
                $sql="SELECT DISTINCT rec_sq_recurso,rec_tx_recurso
                FROM recurso";
                $query=mysqli_query($conn,$sql);
                while ($row = mysqli_fetch_assoc($query)) {
                  $selected = "";
                  if($rec_sq_recurso==$row["rec_sq_recurso"]){
                    $selected = "selected";
                  }

                  $recurso.="<option value=" . $row['rec_sq_recurso'] . " $selected>" . $row['rec_tx_recurso'] . "</option>";
                }

                echo $recurso;
                ?>
              </select>
            </div>
            <div class="form-group form-group col-md-6">
              <label for="">Tema Reunião</label>
              <input type="text" name="agen_tx_temareuniao" value="<?php echo $agen_tx_temareuniao; ?>" class="form-control">
            </div>
          </div>
          <div class="form row">
            <div class="form-group form-group col-md-6">
              <label for="">Inicio Reunião</label>
              <input type="text" name="agen_tx_inicio" value="<?php echo $agen_tx_inicio; ?>" class="form-control">
            </div>
            <div class="form-group form-group col-md-6">
              <label for="">Término Reunião</label>
              <input type="text" name="agen_tx_fim" value="<?php echo $agen_tx_fim; ?>" class="form-control">
            </div>
            <div class="container">
              <div class="form-group">
                <div class="text-right">
                  <button type="submit" class="btn btn-primary mb-2" name="salvar">Enviar</button>
                </div>
              </div>
            </div>
          </form>
        </div>
      </body>
      <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/controller/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
      </html>
