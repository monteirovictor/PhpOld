<?php

 ?>

<!doctype html>
<html lang="pt-br">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="../assets/css/quebralinha.css">

<!--Java Script que evita campo em Branco -->
<script type="text/javascript">

		function validateForm()	{

      //Adiciona as Variaveis a serem comparadas
			var a=document.forms["form1"]["afastamento"].value;
      var b=document.forms["form1"]["recordehh"].value;
      var c=document.forms["form1"]["tfcameta"].value;
      var d=document.forms["form1"]["tfcareal"].value;
      var e=document.forms["form1"]["afastasemaci"].value;
      var f=document.forms["form1"]["rechhsemafast"].value;
      var g=document.forms["form1"]["tfcameta2"].value;
      var h=document.forms["form1"]["tfcareal2"].value;
      var i=document.forms["form1"]["afastasemaciamb"].value;
      var j=document.forms["form1"]["rechhambi"].value;
      var k=document.forms["form1"]["tfcameta3"].value;
      var l=document.forms["form1"]["tfcareal3"].value;
      var m=document.forms["form1"]["afastasemacident"].value;
      var n=document.forms["form1"]["rechhhsemacident"].value;
      var o=document.forms["form1"]["taxacireport"].value;
      var p=document.forms["form1"]["dataanalise"].value;


      //Compara as Variaveis
			if (a==null || a=="") {
				alert("Campo em branco !");
				return false;
			}else if (b==null || b=="") {
        alert("Campo em branco !");
				return false;
      }else if (c==null || c=="") {
        alert("Campo em branco !");
        return false;
      }else if (d==null || d=="") {
        alert("Campo em branco !");
        return false;
      }else if (e==null || e=="") {
        alert("Campo em branco !");
        return false;
      }else if (f==null || f=="") {
        alert("Campo em branco !");
        return false;
      }else if (g==null || g=="") {
        alert("Campo em branco !");
        return false;
      }else if (h==null || h=="") {
        alert("Campo em branco !");
        return false;
      }else if (i==null || i=="") {
        alert("Campo em branco !");
        return false;
      }else if (j==null || j=="") {
        alert("Campo em branco !");
        return false;
      }else if (k==null || k=="") {
        alert("Campo em branco !");
        return false;
      }else if (l==null || l=="") {
        alert("Campo em branco !");
        return false;
      }else if (m==null || m=="") {
        alert("Campo em branco !");
        return false;
      }else if (n=null || n=="") {
        alert("Campo em branco !");
        return false;
      }else if (o==null || o=="") {
        alert("Campo em branco !");
        return false;
      }else if (p==null || p=="") {
        alert("Campo em branco !");
        return false;
      }
		}
	</script>


  <title>Inserção de Informações</title>
  <link rel="shortcut icon" href="../assets/img/icones/favicon.png" type="image/x-png"/>
</head>

<!--Navbar-->
<nav class="navbar navbar-expand-lg navbar-light ">
  <a class="navbar-brand" href="index.php">
  			<img src="../assets/img/icones/logo.png" width="300" height="70" alt="">
  		</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">

    <ul class="navbar-nav mr-auto">

      <li class="nav-item active">
      </li>

      <li class="nav-item">
      </li>

    </ul>

  <form class="form-inline my-2 my-lg-0">
    <a class="btn btn-primary" href="logout.php" role="button">Sair</a>
    </form>

  </div>
</nav>


<body>
  <p></p>
  <div class="text-center">
    <h1>Atualização do Placar Estatístico de Acidente</h1>
  </div>
  <p></p>

  <!--Código Abaixo , contem os dados -->
  <div class="container">

    <form method="post" action="../Dao/infoacidenteDao.php"
    name="form1" onsubmit="return validateForm()">

      <!-- Abaixo será criado um campo Id para o processo de atualização
    no banco de dados , por meio do value -->

    <input type="hidden" class="form-control" aria-describedby=""
    placeholder="" name="id" id="id" value="1" >


      <!--Exibição da 2 etapa do painel -->
      <div class="form-group">
        <label for="">Estamos trabalhando há Horas Homens Trabalhadas <strong> SEM acidentes COM afastamento.</strong></label>
        <input type="text" class="form-control" id="" aria-describedby=""
        placeholder="" name="afastamento" id="afastamento" onkeypress="return SomenteNumero(event)">
      </div>

      <div class="form-group">
        <label for="">Nosso recorde é de Horas Homens Trabalhadas de:</label>
        <input type="text" class="form-control" id="" aria-describedby="" placeholder=""
        name="recordehh" id="recordehh" onkeypress="return SomenteNumero(event)">
      </div>

      <!--Campo do Formulário dividido-->
      <div class="form-row">

        <div class="col">
          <label for="">TFCA - Meta</label>
          <input type="text" class="form-control" placeholder="" name="tfcameta" id="tfcameta" onkeypress="return SomenteNumero(event)">
        </div>

        <div class="col">
          <label for="">Real:</label>
          <input type="text" class="form-control" placeholder="" name="tfcareal" id="tfcareal" onkeypress="return SomenteNumero(event)">
        </div>
      </div>

      <hr id="quebralinha">

      <!--Exibição da 2 etapa do painel -->
      <div class="form-group">
        <label for="">Estamos trabalhando há Horas Homens Trabalhadas <strong>SEM acidentes SEM afastamento.</strong></label>
        <input type="text" class="form-control" id="" aria-describedby="" placeholder="" name="afastasemaci" id="afastasemaci" onkeypress="return SomenteNumero(event)">
      </div>

      <div class="form-group">
        <label for="">Nosso recorde é de Horas Homens Trabalhadas de:</label>
        <input type="text" class="form-control" id="" aria-describedby="" placeholder=""  name="rechhsemafast" id="rechhsemafast" onkeypress="return SomenteNumero(event)">
      </div>

      <!--Campo do Formulário dividido-->
      <div class="form-row">

        <div class="col">
          <label for="">TFSA - Meta</label>
          <input type="text" class="form-control" placeholder="" name="tfcameta2" id="tfcameta2" onkeypress="return SomenteNumero(event)">
        </div>

        <div class="col">
          <label for="">Real:</label>
          <input type="text" class="form-control" placeholder="" name="tfcareal2" id="tfcareal2" onkeypress="return SomenteNumero(event)">
        </div>
      </div>

      <hr id="quebralinha">

      <!--Exibição da 3 etapa do painel -->
      <div class="form-group">
        <label for="">Estamos trabalhando há Horas Homens Trabalhadas <strong> SEM acidentes Ambientais.</strong></label>
        <input type="text" class="form-control" id="" aria-describedby="" placeholder="" name="afastasemaciamb" id="afastasemaciamb" onkeypress="return SomenteNumero(event)">
      </div>

      <div class="form-group">
        <label for="">Nosso recorde é de Horas Homens Trabalhadas de:</label>
        <input type="text" class="form-control" id="" aria-describedby="" placeholder="" name="rechhambi" id="rechhambi" onkeypress="return SomenteNumero(event)">
      </div>

      <!--Campo do Formulário dividido-->
      <div class="form-row">

        <div class="col">
          <label for="">TFSA - Meta</label>
          <input type="text" class="form-control" placeholder=""  name="tfcameta3" id="tfcameta3" onkeypress="return SomenteNumero(event)">
        </div>

        <div class="col">
          <label for="">Real:</label>
          <input type="text" class="form-control" placeholder="" name="tfcareal3" id="tfcareal3" onkeypress="return SomenteNumero(event)">
        </div>
      </div>

      <hr id="quebralinha">

      <!--Exibição da 4 etapa do painel -->
      <div class="form-group">
        <label for="">Estamos trabalhando há Horas Homens Trabalhadas <strong>SEM qualquer acidente.</strong></label>
        <input type="text" class="form-control" id="" aria-describedby="" placeholder="" name="afastasemacident" id="afastasemacident" onkeypress="return SomenteNumero(event)" >
      </div>

      <div class="form-group">
        <label for="">Nosso recorde é de Horas Homens Trabalhadas de:</label>
        <input type="text" class="form-control" id="" aria-describedby="" placeholder=""  name="rechhhsemacident" id="rechhhsemacident" onkeypress="return SomenteNumero(event)">
      </div>

      <div class="form-group">
        <label for="">Taxa de Ocorrência Reportáveis: </label>
        <input type="text" class="form-control" id="" aria-describedby="" placeholder="" id="taxacireport" name="taxacireport" onkeypress="return SomenteNumero(event)">
      </div>

      <div class="form-group">
        <label for="">Nossos números a partir de: </label>
        <input type="text" class="form-control" id="" aria-describedby="" placeholder="EX.: 18/1995" name="dataanalise" id="dataanalise" maxlength="7" OnKeyPress="formatar('##/####', this);return SomenteNumero(event)">
      </div>


      <button type="submit" class="btn btn-primary">Submit</button>

    </form>
    <p></p>
  </div>

  <!-- Footer -->
  <footer class="page-footer font-small blue" style="background-color:#006bb5">
    <!-- Copyright -->
    <div class="footer-copyright text-center py-3">
     © 2018 I.D - Inteligência Digital - Alphatec S.A
    </div>
    <!-- Copyright -->
  </footer>
  <!-- Footer -->



  <!-- Optional JavaScript -->
  <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
  <script src="../assets/js/bootstrap.min.js"></script>
  <script src="../assets/js/data.js"></script>
  <script src="../assets/js/Somentenumero.js"></script>
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
</body>

</html>
