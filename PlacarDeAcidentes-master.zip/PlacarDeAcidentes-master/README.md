# PlacarDeAcidentes
Placar de Acidentes, desenvolvido em PHP para atualizar os funcionários de uma Empresa a respeito dos Acidentes Onshore e Offshore
