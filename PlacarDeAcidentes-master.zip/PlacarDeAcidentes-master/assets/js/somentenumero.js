//função que trata os campos de input , para receber somente
// numeros, virgula e ponto. as informações são baseadas na
//tabela ASCII;


function SomenteNumero(e) {
    var tecla = (window.event) ? event.keyCode : e.which;
    if ((tecla > 47 && tecla < 58 || tecla == 44)) return true;
    else {
        if ((tecla > 47 && tecla < 58 || tecla == 46)) return true;
        else {
            if (tecla == 8 || tecla == 0) return true;
            else return false;
        }
    }
}
