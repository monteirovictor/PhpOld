-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: 22-Out-2018 às 13:30
-- Versão do servidor: 5.7.21
-- PHP Version: 5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `teste`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `somast`
--

DROP TABLE IF EXISTS `somast`;
CREATE TABLE IF NOT EXISTS `somast` (
  `id` int(11) NOT NULL,
  `afastamento` varchar(40) NOT NULL,
  `recordehh` varchar(40) NOT NULL,
  `tfcameta` varchar(40) NOT NULL,
  `tfcareal` varchar(40) NOT NULL,
  `afastasemaci` varchar(40) NOT NULL,
  `rechhsemafast` varchar(40) NOT NULL,
  `tfcameta2` varchar(40) NOT NULL,
  `tfcareal2` varchar(40) NOT NULL,
  `afastasemaciamb` varchar(40) NOT NULL,
  `rechhambi` varchar(40) NOT NULL,
  `tfcameta3` varchar(40) NOT NULL,
  `tfcareal3` varchar(40) NOT NULL,
  `afastasemacident` varchar(40) NOT NULL,
  `rechhhsemacident` varchar(40) NOT NULL,
  `taxacireport` varchar(40) NOT NULL,
  `dataanalise` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `somast`
--

INSERT INTO `somast` (`id`, `afastamento`, `recordehh`, `tfcameta`, `tfcareal`, `afastasemaci`, `rechhsemafast`, `tfcameta2`, `tfcareal2`, `afastasemaciamb`, `rechhambi`, `tfcameta3`, `tfcareal3`, `afastasemacident`, `rechhhsemacident`, `taxacireport`, `dataanalise`) VALUES
(1, '222', '22', '22', '22', '222', '22', '40', '40', '40', '40', '40', '40', '40', '40', '40', '40');

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE IF NOT EXISTS `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `matricula` varchar(20) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `login` varchar(255) NOT NULL,
  `senha` varchar(50) NOT NULL,
  `situacoes_id` varchar(1) NOT NULL,
  `niveis_acesso_id` varchar(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=114 DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `matricula`, `nome`, `login`, `senha`, `situacoes_id`, `niveis_acesso_id`) VALUES
(2, 'id', 'id', 'id', '468d62aeb707889ac0f9eda70fdf9991', '1', '1'),
(1, 'portaria', 'portaria', 'portaria.portaria', '468d62aeb707889ac0f9eda70fdf9991', '1', '1');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
