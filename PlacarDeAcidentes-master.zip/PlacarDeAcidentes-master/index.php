<?php
//Include de conexao
include_once("Dao/factoryconexao.php");
//Include de busca
include_once("Dao/somastDao.php");
 ?>

<!doctype html>
<html lang="pt-br">
<meta http-equiv="refresh" content="220">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/css/quebralinha.css">

  <title>Placar Estátistico de Acidentes</title>
  <link rel="shortcut icon" href="assets/img/icones/favicon.png" type="image/x-png"/>
</head>

<!--Navbar-->
<nav class="navbar navbar-expand-lg navbar-light " style="background-color: white">
  <a class="navbar-brand" href="index.php">
  			<img src="assets/img/icones/logo.png" width="300" height="70" alt="">
  		</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">

    <ul class="navbar-nav mr-auto">

      <li class="nav-item active">
      </li>

      <li class="nav-item">
      </li>

    </ul>

  <form class="form-inline my-2 my-lg-0">
    <a class="btn btn-primary" href="http://intranet/" role="button">Voltar</a>
    </form>

  </div>
</nav>

<body>
<div class="text-center">
    <img src="assets/img/1.PNG" alt="Placar de Acidentes"  class="img-fluid"  width="700" height="270">
  </div>
  <p></p>

  <!--Código Abaixo , contem os dados -->
  <div class="container">

    <form>

      <!--Exibição da 2 etapa do painel -->
      <div class="form-group">
        <label for="">Estamos há
          <?php echo "<font size=5><b>".$row_consulta['afastamento']."</b></font>";   echo " <b>hh</b>"; ?>
          Trabalhadas <strong> sem acidentes COM AFASTAMENTO.</strong>
        </label>
      </div>

      <div class="form-group">
        <label for="">Nosso recorde é de  <?php echo "<font size=5><b>".$row_consulta['recordehh']."</b></font>";
        echo " <b>hh</b>";?> Trabalhadas</label>
      </div>

      <!--Campo do Formulário dividido-->
      <div class="form-row">

        <div class="col">
          <label for="">TFCA - Meta : <?php echo "<b>".$row_consulta['tfcameta']."</b>"; ?></label>
        </div>

        <div class="col">
          <label for="">Real:<?php echo "<b>".$row_consulta['tfcareal']."</b>";?></label>
        </div>
      </div>

      <hr id="quebralinha">

      <!--Exibição da 2 etapa do painel -->
      <div class="form-group">
        <label for="">Estamos há
          <?php echo "<font size=5><b>".$row_consulta['afastasemaci']."</b></font>";  echo " <b>hh</b>";?>
           Trabalhadas <strong> sem acidentes SEM AFASTAMENTO.</strong>
          </label>
      </div>

      <div class="form-group">
        <label for="">Nosso recorde é
          <?php echo "<font size=5><b>".$row_consulta['rechhsemafast']."</b></font>";
          echo " <b>hh</b>";?> Trabalhadas </label>
      </div>

      <!--Campo do Formulário dividido-->
      <div class="form-row">

        <div class="col">
          <label for="">TFSA - Meta :<?php echo "<b>".$row_consulta['tfcameta2']."</b>"; ?></label>
        </div>

        <div class="col">
          <label for="">Real: <?php echo "<b>".$row_consulta['tfcareal2']."</b>"; ?></label>
        </div>
      </div>

      <hr id="quebralinha">

      <!--Exibição da 3 etapa do painel -->
      <div class="form-group">
        <label for="">Estamos há   <?php echo "<font size=5><b>".$row_consulta['afastasemaciamb']."</b></font>";  echo " <b>hh</b>";?>
           Trabalhadas<strong> SEM acidentes Ambientais.</strong>
        </label>
      </div>

      <div class="form-group">
        <label for="">Nosso recorde é
          <?php echo "<font size=5><b>".$row_consulta['rechhambi']."</b></font>";  echo " <b>hh</b>";?> Trabalhadas</label>
      </div>

      <!--Campo do Formulário dividido-->
      <div class="form-row">

        <div class="col">
          <label for="">TFAA - Meta:<?php  echo "<b>".$row_consulta['tfcameta3']."</b>"; ?></label>
        </div>

        <div class="col">
          <label for="">Real:<?php echo "<b>".$row_consulta['tfcareal3']."</b>"; ?></label>
        </div>
      </div>

      <hr id="quebralinha">

      <!--Exibição da 4 etapa do painel -->
      <div class="form-group">
        <label for="">Estamos há <?php echo "<font size=5><b>".$row_consulta['afastasemacident']."</b></font>";
        echo "<b> hh</b>";?>
         Trabalhadas <strong> SEM qualquer acidente.</strong>
          </label>
      </div>

      <div class="form-group">
        <label for="">Nosso recorde é de <?php echo "<font size=5><b>".$row_consulta['rechhhsemacident']. "</b></font>";
           echo " <b> hh</b>";?>
            Trabalhadas
        </label>
      </div>

      <!--Campo do Formulário dividido-->
      <div class="form-row">

        <div class="col">
          <label for="">TOR - Taxa de Ocorrência Reportáveis:
            <?php echo "<b>".$row_consulta['taxacireport']. "</b>"; ?></label>
        </div>
		
		 <div class="col">
          <label for="">Real:
            <?php echo "<b>".$row_consulta['torreal']. "</b>"; ?></label>
        </div>

        <div class="col">
          <label for="">Nossos números a partir de:
            <?php echo "<b>" .$row_consulta['dataanalise']. "</b>" ; ?></label>
        </div>
      </div>

    </form>
    <p></p>
  </div>

  <!-- Footer -->
  <footer class="page-footer font-small blue" style="background-color:#006bb5">
    <!-- Copyright -->
    <div class="footer-copyright text-center py-3">
    <a href="http://intranet/"><p style="color:white">© 2018 I.D - Inteligência Digital - Alphatec S.A</p></a>
    </div>
    <!-- Copyright -->
  </footer>
  <!-- Footer -->



  <!-- Optional JavaScript -->
  <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
  <script src="assets/js/bootstrap.min.js"></script>
</body>

</html>
