<?php

//conexao com o banco de dados
include_once("factoryconexao.php");

$id=$_POST['id'];
$afastamento=$_POST['afastamento'];
$recordehh=$_POST['recordehh'];
$tfcameta=$_POST['tfcameta'];
$tfcareal=$_POST['tfcareal'];
$afastasemaci=$_POST['afastasemaci'];
$rechhsemafast=$_POST['rechhsemafast'];
$tfcameta2=$_POST['tfcameta2'];
$tfcareal2=$_POST['tfcareal2'];
$afastasemaciamb=$_POST['afastasemaciamb'];
$rechhambi=$_POST['rechhambi'];
$tfcameta3=$_POST['tfcameta3'];
$tfcareal3=$_POST['tfcareal3'];
$afastasemacident=$_POST['afastasemacident'];
$rechhhsemacident=$_POST['rechhhsemacident'];
$taxacireport=$_POST['taxacireport'];
$dataanalise=$_POST['dataanalise'];

$queryupdate= "UPDATE somast SET afastamento = '$afastamento' ,
recordehh = '$recordehh', tfcameta = '$tfcameta', tfcareal='$tfcareal',
afastasemaci='$afastasemaci',rechhsemafast='$rechhsemafast',
tfcameta2='$tfcameta2',tfcareal2='$tfcareal2',
afastasemaciamb ='$afastasemaciamb',
rechhambi='$rechhambi',tfcameta3='$tfcameta3',tfcareal3='$tfcareal3',
afastasemacident='$afastasemacident',rechhhsemacident='$rechhhsemacident',
taxacireport ='$taxacireport',dataanalise='$dataanalise' WHERE id =$id ";

$resultado_queryupdate=mysqli_query($conn,$queryupdate);

?>

<!DOCTYPE html>
<html>
<head>
	<title>

	</title>
</head>
<body>
	<meta http-equiv="refresh" content="2;URL=../Administrador/insercaoinfoacidente.php" />
</body>

</html>
