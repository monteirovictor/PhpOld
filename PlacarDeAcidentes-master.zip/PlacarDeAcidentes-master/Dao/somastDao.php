<?php

//Consulta de Busca
$result_consulta = "SELECT * FROM somast ";
$resultado_consulta = mysqli_query($conn, $result_consulta);
$row_consulta = mysqli_fetch_assoc($resultado_consulta);

 ?>
