# Portaria
Sistema que exibe informações de funcionários bem como seu status (Férias, Demitido, Aviso Prévio , licensa) , para uma portaria (Guarita).
