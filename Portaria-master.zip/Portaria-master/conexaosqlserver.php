


<?php
 //AUMENTANDO TEMPO DETIMEOUT
		  set_time_limit(600);
$connection_string = 'DRIVER={SQL Server};SERVER=10.100.0.3;DATABASE=CORPORERM';
$user = 'rm';
$pass = 'rm';
$connection = odbc_connect( $connection_string, $user, $pass ) or die('Erro de conexao com o banco de dados do RM');

 //Ancentuação do sqlserver
		// header('Content-Type: text/html; charset=iso-8859-1',true);
?>
