
<?php
include("conexao.php");
include('conexaosqlserver.php');

$buscar = $_POST['buscar'];

$sqlRM = "SELECT CHAPA, NOME_PESSOA,SITUACAO, SETOR, CPF, CONVERT(VARCHAR(10), DATAADMISSAO, 103) AS DATAADMISSAO, CONVERT(VARCHAR(10), DATADEMISSAO, 103) AS DATADEMISSAO
				  FROM FS_FUNCIONARIO
					WHERE CHAPA = '$buscar'";
$queryRM = odbc_exec($connection, $sqlRM);

$funcionarioRM = array();
while ($row = odbc_fetch_array($queryRM)) {

	$funcionarioRM[$row['CHAPA']] = array('CHAPA' => $row['CHAPA'],

	// O Comando iconv , corrige erros de caracter vindos do sql server;

																				'NOME' => iconv("ISO-8859-1", "UTF-8", $row['NOME_PESSOA']),
																				'SETOR' =>iconv("ISO-8859-1", "UTF-8", $row['SETOR']),
																				'CPF' => $row['CPF'],
																				'SITUACAO' => iconv("ISO-8859-1", "UTF-8", $row['SITUACAO']),
																			//	'SITUACAO' => $row['SITUACAO'],
																				'DATAADMISSAO' => $row['DATAADMISSAO'],
																				'DATADEMISSAO' => $row['DATADEMISSAO']);
}

//


?>

<!DOCTYPE html>
<html>

<head>
	<!--Import Google Icon Font-->
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	<!--Import materialize.css-->
	<link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>
	<!--Let browser know website is optimized for mobile-->
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<meta charset="utf-8">

	<title>Listar</title>

	<nav>
		<div class="nav-wrapper blue darken-2">
			<ul id="nav-mobile" class="right hide-on-med-and-down">
				<li><a href="listar.php">Voltar</a></li>
			</ul>
		</div>
	</nav>
</head>
<body>

	<br><br><br><br>

	<center>
		<form class="col s12" method="POST" action="">
			<div class="row">
				<table>
					<thead>
						<tr>
							<th>Nome</th>
							<th>S.A</th>
							<th>Setor</th>
							<th>CPF</th>
							<th>Data Admissão</th>
							<th>Data Demissão</th>
							<th>Situação</th>

						</tr>
					</thead>

					<tbody>

						<!--loop para printar -->

						<?php

						$cursos = "SELECT  * FROM talento WHERE sa = '$buscar'  ";
						$resultado_cursos = mysqli_query($conn, $cursos);
						
					
						while($rows = mysqli_fetch_assoc($resultado_cursos)){
							echo "<tr>";
							echo "<td>".$funcionarioRM[$rows['sa']]['NOME']."</td>";
							echo "<td>".$funcionarioRM[$rows['sa']]['CHAPA']."</td>";
							echo "<td>".$funcionarioRM[$rows['sa']]['SETOR']."</td>";
							echo "<td>".$funcionarioRM[$rows['sa']]['CPF']."</td>";
							echo "<td>".$funcionarioRM[$rows['sa']]['DATAADMISSAO']."</td>";
							echo "<td>".$funcionarioRM[$rows['sa']]['DATADEMISSAO']."</td>";
						
						    $color = completePayment($funcionarioRM[$rows['sa']]['SITUACAO']);
							echo  "<td> <b style='background: {$color}; color:#black ;'>".$funcionarioRM[$rows['sa']]['SITUACAO']."</b></td> ";
							
							
							
							
						$src=$rows['URL'];
						$alt=$rows['DESCRICAO'];
							echo '<img src="' . $src . '" alt="' . $alt . '"  width="220" height="280" />';
							echo "</tr>";
						}
   

						function completePayment($cod){

						    switch($cod){
						        default:
						            $color = "#FFFFFF";
						            break;
										
						        case 'Af.Previdência':
						            $color = "#ffa500";
						            break;

						        case 'Apos. Invalidez':
						            $color = "#ffa500";
						            break;

										case 'Ativo':
													 $color = "green";
													 break;

									 case 'Aviso Prévio':
													$color = "#ffa500";
													break;

										case 'Contrato de Trabalho Suspenso':
													$color = "#ffa500";
									  			break;

										case 'Demitido':
													$color = "red";
													break;

										case 'Férias':
													$color = "#1976d2";
													break;

										case 'Licença Mater.':
													$color = "#ffa500";
													break;


						    }

						    return $color;

						}
						
					
						
						
						?>


					</tbody>
				</table>

			</div>
		</form>
	</center>

	<!--Import jQuery before materialize.js-->
	<script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
	<script type="text/javascript" src="js/materialize.min.js"></script>
</body>
</html>
