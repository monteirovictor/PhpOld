

<?php
include("conexao.php");
?>


<!DOCTYPE html>
<html>
<style>
body {

	background-image: url(images/fundo1.png);
	background-attachment: scroll;
	background-size: 100%;
	background-repeat: no-repeat;
	background-color: white;
}
</style>
<head>
	<!--Import Google Icon Font-->
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	<!--Import materialize.css-->
	<link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>
	<!--Let browser know website is optimized for mobile-->
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<meta charset="utf-8">
	

	<script type="text/javascript">
		function validateForm()	{
			var x=document.forms["form1"]["buscar"].value;
			if (x==null || x==""){
				alert("Campo em branco !");
				return false;
			}
		}
	</script>


	<title>Inicio</title>
	
	<nav>
		<div class="nav-wrapper blue darken-2">
			<ul id="nav-mobile" class="right hide-on-med-and-down">
				<li><a href="http://intranet/">Voltar</a></li>
			</ul>
		</div>
	</nav>
</head>
<body>


	<br><br><br><br><br><br>
	<br><br><br><br><br><br>
	<br><br><br><br><br><br>


	<div class="row">
		<center>
			<form class="col s12" method="POST" action="pesquisar.php" name="form1" onsubmit="return validateForm()">
				<div class="row">

					<div class="input-field col s12">
						<label>Buscar</label><br><br>
						<input id="buscar" name="buscar" class="validate" type="text" value="" placeholder="Nome , S.A ou Setor"><br><br>
					</div>


					<!-- Botões de avançar -->

					<button class="btn waves-effect waves-light blue darken-2" type="submit" name="action">Buscar
						<i class="material-icons right">send</i>
					</button>

				</div>
			</form>
		</center>
	</div>







	<!--Import jQuery before materialize.js-->
	<script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
	<script type="text/javascript" src="js/materialize.min.js"></script>
</body>
</html>