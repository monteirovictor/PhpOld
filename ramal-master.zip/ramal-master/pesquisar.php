
<?php
include("conexao.php");
?>

<!DOCTYPE html>
<html>

<head>
	<!--Import Google Icon Font-->
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	<!--Import materialize.css-->
	<link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>
	<!--Let browser know website is optimized for mobile-->
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<meta charset="utf-8">
	


	<title>Listar</title>
	
	<nav>
		<div class="nav-wrapper blue darken-2">
			<ul id="nav-mobile" class="right hide-on-med-and-down">
				<li><a href="listar.php">Voltar</a></li>
			</ul>
		</div>
	</nav>
</head>
<body>


	<br><br><br><br>

	<center>
		<form class="col s12" method="POST" action="">
			<div class="row">
				<table>
					<thead>
						<tr>
							<th>S.A</th>
							<th>Talento</th>
							<th>E-mail</th>
							<th>Celular</th>
							<th>Setor</th>
							<th>Ramal</th>
						</tr>
					</thead>

					<tbody>
						
						<!--loop para printar -->
						
						<?php
						

						$buscar = $_POST['buscar'];
						$cursos = "SELECT * FROM ramal WHERE funcionario LIKE '%$buscar%' ";
						$resultado_cursos = mysqli_query($conn, $cursos);

						
						while($rows = mysqli_fetch_assoc($resultado_cursos)){
							echo "<tr>";
							echo "<td>".$rows['matricula']."</td>";
							echo "<td>".$rows['funcionario']."</td>";
							echo "<td>".$rows['email']."</td>";
							echo "<td>".$rows['celular']."</td>";
							echo "<td>".$rows['setor']."</td>";
							echo "<td>".$rows['ramal']."</td>";

							echo "</tr>";
						}
						
						$buscar = $_POST['buscar'];
						$cursos = "SELECT * FROM ramal WHERE matricula LIKE '%$buscar%'  ";
						$resultado_cursos = mysqli_query($conn, $cursos);
						while($rows = mysqli_fetch_assoc($resultado_cursos)){

							echo "<tr>";
							echo "<td>".$rows['matricula']."</td>";
							echo "<td>".$rows['funcionario']."</td>";
							echo "<td>".$rows['email']."</td>";
							echo "<td>".$rows['celular']."</td>";
							echo "<td>".$rows['setor']."</td>";
							echo "<td>".$rows['ramal']."</td>";

							echo "</tr>";
						}


						$buscar = $_POST['buscar'];
						$cursos = "SELECT * FROM ramal WHERE setor LIKE '%$buscar%'  ";
						$resultado_cursos = mysqli_query($conn, $cursos);
						while($rows = mysqli_fetch_assoc($resultado_cursos)){

							echo "<tr>";
							echo "<td>".$rows['matricula']."</td>";
							echo "<td>".$rows['funcionario']."</td>";
							echo "<td>".$rows['email']."</td>";
							echo "<td>".$rows['celular']."</td>";
							echo "<td>".$rows['setor']."</td>";
							echo "<td>".$rows['ramal']."</td>";

							echo "</tr>";
						}

						?>


					</tbody>
				</table>

					<!-- Botões de avaçar e voltar

					<button class="btn waves-effect waves-light blue darken-2" type="submit" name="action">
					<a href="logout.php" style="color: white">Sair</a>
				</button>-->
			</div>
		</form>
	</center>




	





	<!--Import jQuery before materialize.js-->
	<script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
	<script type="text/javascript" src="js/materialize.min.js"></script>
</body>
</html>
